const http = require('http')
const fs = require('fs')
const { text } = require('node:stream/consumers')
const port = 3000 
let mysql = require('mysql');
let connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Temka2467',
  database: 'tvmvlvndb'
});

const server = http.createServer(function(req, res){
    if(req.url == "/insert"){
        connection.query('INSERT INTO `employees5` (`employee_id`, `employee_salary`, `employee_age`) VALUES ("1", "1104000" , "19")', function (error, results) {
            if (error) throw error;
            console.log('The solution is: ', results);
          });
        res.end()
    } ;
    if(req.url == "/update") {
        connection.query('UPDATE `employees5` SET `employee_id`="3",`employee_salary`="2500",`employee_age`="32" where `employee_id`="1"', function (error, results) {
            if (error) throw error;
            console.log('The solution is: ', results);
          });
          res.end()
    } 
    if(req.url == "/Delete") {
        connection.query('delete from employees5 where employee_id="3"', function (error, results) {
            if (error) throw error;
            console.log('The solution is: ', results);
          });
          res.end()
    } 

    res.writeHead(200, {'Content-type' : 'text/html'})
    fs.readFile('2rd.html', function(error, data){
        if(error){
            res.writeHead('404')
            res.write('Error: Not found kk ')
        } else {
            res.write(data)
        }
        res.end()
    })
})
server.listen(port, function(error){
    if(error){
        console.log('went wrong' + error)
    } else {
        console.log('Listening on ' + port)
    }
})

connection.connect(function(err) {
    if (err) {
      return console.error('error: ' + err.message);
      connection.end(function(err) {
        if (err) {
          return console.log(err.message);
        }
      });
    }
    console.log('db connect');
  });

  var employee = 'create table employees5(employee_id int,employee_salary int not null,employee_age int);'
  connection.query( employee, function(error, results, fields) {
    if (error) {
      console.log(error.message);
    }
    else{
      console.log('query done');
    }

  });

//   connection.query('INSERT INTO `employees4` (`employee_id`, `employee_salary`, `employee_age`) VALUES ("1", "1104000" , "19")', function (error, results) {
//     if (error) throw error;
//     console.log('The solution is: ', results);
//   });
   
//   var UpdateQ = connection.query('UPDATE `employees4` SET `employee_id`="3",`employee_salary`="2500",`employee_age`="32" where `employee_id`="1"', function (error, results) {
//     if (error) throw error;
//     console.log('The solution is: ', results);
//   });
   
//   var SelectQ = connection.query('select * from employees4', function (error, results) {
//     if (error) throw error;
//     console.log('The solution is: ', results);
//   });
 
//   var DeleteQ = connection.query('delete from employees4 where employee_id="3"', function (error, results) {
//     if (error) throw error;
//     console.log('The solution is: ', results);
//   });
   